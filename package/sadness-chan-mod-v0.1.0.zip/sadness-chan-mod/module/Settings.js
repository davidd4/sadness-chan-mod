class Settings {
    constructor() {
        this.sadnessModuleName = 'sadness-chan';
        this.moduleName = 'sadness-chan-mod';
        this.SETTING_KEYS = {
            COUNTER: 'counter',
            AVERAGE_TOGGLE: 'averageToggle',
        };
    }
    static getInstance() {
        if (!Settings._instance)
            Settings._instance = new Settings();
        return Settings._instance;
    }
    registerSettings() {
        // Register any custom module settings here
    }
    getSadnessSetting(key) {
        return this._getSetting(this.sadnessModuleName, key);
    }
    getCounter() {
        const setting = this.getSadnessSetting(this.SETTING_KEYS.COUNTER);
        try {
            return JSON.parse(setting);
        }
        catch (error) {
            return {};
        }
    }
    _getSetting(module, key) {
        return game.settings.get(module, key);
    }
}
export default Settings.getInstance();
